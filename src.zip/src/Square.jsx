import React from 'react';

// 一个正方形的框框,使用button作为一个框框
class Square extends React.Component{
    constructor(props) {
        super(props);
        // 三个可定义的state
        this.state = {
            hili: false
        };
    }
    render() {
        return (
        // 没有括号不是自执行函数
            <button className={this.state.hili?"hiliSquare":"square"} onClick={this.props.onClick}>
                {this.props.value}
            </button>
        );
    }
    
}

export default Square;